import { Plane } from "./plane";

export const PLANES:  Plane[] = 
[/*
    {id: 1, name: "F-117", country: "US",maxAltitude: 45000, maxSpeed: 594, role: "Attack", manufacturer: "Lockheed",p1: "p1", p2: "p12", p3: "p13", p4: "p14",imgs: ["p1","p12","p13","p14"]},
    {id: 2, name: "SR-71", country: "US",maxAltitude: 85000, maxSpeed: 1910, role: "Reconnaissance", manufacturer: "Lockheed",p1: "p2", p2: "p2", p3: "p2", p4: "p2",imgs: ["p1","p12","p13","p14"]},
    {id: 3, name: "B-2", country: "US",maxAltitude: 50000, maxSpeed: 550, role: "Attack", manufacturer: "Lockheed",p1: "p3", p2: "p3", p3: "p3", p4: "p3",imgs: ["p1","p12","p13","p14"]},
    {id: 4, name: "U-2", country: "US",maxAltitude: 80000, maxSpeed: 413, role: "Reconnaissance", manufacturer: "Lockheed",p1: "p4", p2: "p4", p3: "p4", p4: "p4",imgs: ["p1","p12","p13","p14"]}*/
];